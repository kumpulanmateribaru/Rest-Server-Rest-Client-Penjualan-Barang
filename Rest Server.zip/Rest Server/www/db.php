<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","mulf9537_penjualan","penjualan","mulf9537_penjualan") or die ("could not connect database");
?>